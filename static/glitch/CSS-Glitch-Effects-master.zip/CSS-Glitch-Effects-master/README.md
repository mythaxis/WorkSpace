# CSS-Glitch-Effects
Text Glitch Animation Effects Using Pure HTML5 and CSS3 Only. </br>

Just download the respository and unzip the file. </br>

Open index.html file and here you go. </br>

Enjoy the text glitch animation effects.</br>

<h4>Follow me in github for more intresting project</h4>

![](text-glitch-animation.gif)
